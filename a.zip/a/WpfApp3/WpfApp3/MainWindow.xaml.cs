﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using WpfApp3.Models;

namespace WpfApp3
{
    public partial class MainWindow : Window
    {
        // Biến DbContext để kết nối và thao tác với cơ sở dữ liệu SQL Server
        private QlbanHangContext db;

        // Hàm khởi tạo: Thiết lập cửa sổ và tải dữ liệu ban đầu
        public MainWindow()
        {
            try
            {
                InitializeComponent(); // Khởi tạo giao diện từ file XAML
                db = new QlbanHangContext(); // Khởi tạo đối tượng DbContext để kết nối cơ sở dữ liệu
                LoadData(); // Gọi hàm tải dữ liệu sản phẩm lên DataGrid
                LoadComboBox(); // Gọi hàm tải danh sách loại sản phẩm vào ComboBox
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có vấn đề xảy ra trong quá trình khởi tạo
                MessageBox.Show($"Lỗi khi khởi tạo ứng dụng: {ex.Message}", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Hàm tải dữ liệu sản phẩm từ cơ sở dữ liệu và hiển thị lên DataGrid
        private void LoadData()
        {
            try
            {
                // Truy vấn LINQ để lấy danh sách sản phẩm cùng thông tin loại sản phẩm
                var sanPhams = db.SanPhams
                    .Include(sp => sp.MaLoaiNavigation) // Kết hợp thông tin loại sản phẩm liên quan
                    .Select(sp => new // Tạo một kiểu ẩn danh để hiển thị các cột cần thiết
                    {
                        sp.MaSp, // Mã sản phẩm
                        sp.TenSp, // Tên sản phẩm
                        sp.MaLoaiNavigation, // Đối tượng loại sản phẩm liên quan
                        sp.DonGia, // Đơn giá của sản phẩm
                        sp.SoLuong, // Số lượng tồn kho
                        ThanhTien = sp.DonGia * sp.SoLuong // Thành tiền (tính toán từ đơn giá và số lượng)
                    })
                    .OrderBy(sp => sp.DonGia) // Sắp xếp sản phẩm theo đơn giá tăng dần
                    .ToList(); // Chuyển kết quả truy vấn thành danh sách để sử dụng
                dgSanPham.ItemsSource = sanPhams; // Gán danh sách này làm nguồn dữ liệu cho DataGrid
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có vấn đề khi tải dữ liệu từ cơ sở dữ liệu
                MessageBox.Show($"Lỗi khi tải dữ liệu: {ex.Message}", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Hàm tải danh sách loại sản phẩm vào ComboBox
        private void LoadComboBox()
        {
            try
            {
                // Lấy toàn bộ danh sách loại sản phẩm từ bảng LoaiSanPham và gán vào ComboBox
                cbLoaiSP.ItemsSource = db.LoaiSanPhams.ToList();
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu không tải được danh sách loại sản phẩm
                MessageBox.Show($"Lỗi khi tải danh sách loại sản phẩm: {ex.Message}", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Hàm xử lý sự kiện khi nhấn nút "Sửa"
        private void BtnSua_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Kiểm tra tất cả các trường nhập liệu có được điền đầy đủ không
                if (string.IsNullOrEmpty(txtMaSP.Text) || string.IsNullOrEmpty(txtTenSP.Text) ||
                    string.IsNullOrEmpty(txtDonGia.Text) || string.IsNullOrEmpty(txtSoLuong.Text) ||
                    cbLoaiSP.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin cần sửa!", "Cảnh báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Tìm sản phẩm trong cơ sở dữ liệu dựa trên mã sản phẩm nhập vào
                var sanPham = db.SanPhams.Find(txtMaSP.Text);
                if (sanPham == null)
                {
                    // Nếu không tìm thấy sản phẩm, hiển thị thông báo lỗi
                    MessageBox.Show($"Không tìm thấy sản phẩm với mã '{txtMaSP.Text}'!", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                // Kiểm tra và chuyển đổi đơn giá từ chuỗi sang số nguyên
                if (!int.TryParse(txtDonGia.Text, out int donGia) || donGia <= 0)
                {
                    MessageBox.Show("Đơn giá phải là số nguyên dương!", "Cảnh báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                // Kiểm tra và chuyển đổi số lượng từ chuỗi sang số nguyên
                if (!int.TryParse(txtSoLuong.Text, out int soLuong) || soLuong <= 0)
                {
                    MessageBox.Show("Số lượng phải là số nguyên dương!", "Cảnh báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Cập nhật thông tin sản phẩm với dữ liệu mới từ giao diện
                sanPham.TenSp = txtTenSP.Text; // Cập nhật tên sản phẩm
                sanPham.DonGia = donGia; // Cập nhật đơn giá
                sanPham.SoLuong = soLuong; // Cập nhật số lượng
                sanPham.MaLoai = cbLoaiSP.SelectedValue.ToString(); // Cập nhật mã loại sản phẩm từ ComboBox

                // Đánh dấu trạng thái đối tượng đã bị sửa đổi để Entity Framework theo dõi
                db.Entry(sanPham).State = EntityState.Modified;

                // Lưu thay đổi vào cơ sở dữ liệu và kiểm tra kết quả
                int rowsAffected = db.SaveChanges();
                if (rowsAffected > 0)
                {
                    LoadData(); // Làm mới danh sách sản phẩm trong DataGrid
                    ClearInputs(); // Xóa trắng các trường nhập liệu sau khi sửa thành công
                    MessageBox.Show("Sửa sản phẩm thành công!", "Thành công", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    // Nếu không có dòng nào được cập nhật, thông báo cảnh báo
                    MessageBox.Show("Không có thay đổi nào được lưu!", "Cảnh báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            catch (DbUpdateException ex)
            {
                // Xử lý lỗi đặc biệt liên quan đến cơ sở dữ liệu (ví dụ: vi phạm ràng buộc khóa ngoại)
                MessageBox.Show($"Lỗi khi lưu thay đổi vào cơ sở dữ liệu: {ex.InnerException?.Message}", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                // Xử lý các lỗi không xác định khác trong quá trình sửa
                MessageBox.Show($"Lỗi không xác định khi sửa sản phẩm: {ex.Message}", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Hàm xử lý sự kiện khi nhấn nút "Thêm"
        private void BtnThem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Kiểm tra xem tất cả các trường nhập liệu có được điền không
                if (string.IsNullOrEmpty(txtMaSP.Text) || string.IsNullOrEmpty(txtTenSP.Text) ||
                    string.IsNullOrEmpty(txtDonGia.Text) || string.IsNullOrEmpty(txtSoLuong.Text) ||
                    cbLoaiSP.SelectedItem == null)
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Cảnh báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Kiểm tra và chuyển đổi đơn giá, số lượng thành số nguyên dương
                if (!int.TryParse(txtDonGia.Text, out int donGia) || donGia <= 0 ||
                    !int.TryParse(txtSoLuong.Text, out int soLuong) || soLuong <= 0)
                {
                    MessageBox.Show("Đơn giá và số lượng phải là số nguyên dương!", "Cảnh báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Tạo một sản phẩm mới từ dữ liệu nhập vào
                var sanPham = new SanPham
                {
                    MaSp = txtMaSP.Text, // Mã sản phẩm
                    TenSp = txtTenSP.Text, // Tên sản phẩm
                    DonGia = donGia, // Đơn giá
                    SoLuong = soLuong, // Số lượng
                    MaLoai = cbLoaiSP.SelectedValue.ToString() // Mã loại sản phẩm
                };

                db.SanPhams.Add(sanPham); // Thêm sản phẩm mới vào DbContext
                db.SaveChanges(); // Lưu sản phẩm vào cơ sở dữ liệu
                LoadData(); // Làm mới DataGrid
                ClearInputs(); // Xóa trắng các trường nhập liệu
                MessageBox.Show("Thêm sản phẩm thành công!", "Thành công", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (DbUpdateException ex)
            {
                // Xử lý lỗi nếu thêm sản phẩm thất bại (ví dụ: trùng mã sản phẩm)
                MessageBox.Show($"Lỗi khi thêm sản phẩm (có thể trùng mã): {ex.InnerException?.Message}", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                // Xử lý các lỗi không xác định khác khi thêm
                MessageBox.Show($"Lỗi không xác định khi thêm: {ex.Message}", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Hàm xử lý sự kiện khi nhấn nút "Xóa"
        private void BtnXoa_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Kiểm tra xem mã sản phẩm có được nhập không
                if (string.IsNullOrEmpty(txtMaSP.Text))
                {
                    MessageBox.Show("Vui lòng nhập mã sản phẩm cần xóa!", "Cảnh báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Tìm sản phẩm theo mã
                var sanPham = db.SanPhams.Find(txtMaSP.Text);
                if (sanPham != null)
                {
                    // Hiển thị hộp thoại xác nhận trước khi xóa
                    if (MessageBox.Show("Bạn có chắc muốn xóa sản phẩm này?", "Xác nhận",
                        MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        db.SanPhams.Remove(sanPham); // Xóa sản phẩm khỏi DbContext
                        db.SaveChanges(); // Lưu thay đổi vào cơ sở dữ liệu
                        LoadData(); // Làm mới DataGrid
                        ClearInputs(); // Xóa trắng các trường nhập liệu
                        MessageBox.Show("Xóa sản phẩm thành công!", "Thành công", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                else
                {
                    // Thông báo nếu không tìm thấy sản phẩm để xóa
                    MessageBox.Show("Không tìm thấy sản phẩm để xóa!", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu xóa thất bại (ví dụ: lỗi kết nối cơ sở dữ liệu)
                MessageBox.Show($"Lỗi khi xóa sản phẩm: {ex.Message}", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Hàm xử lý sự kiện khi nhấn nút "Tìm" để hiển thị thông tin bán hàng
        private void BtnTim_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Tạo một cửa sổ mới để hiển thị thông tin bán hàng
                var salesWindow = new Window
                {
                    Title = "Thông Tin Bán Hàng", // Tiêu đề cửa sổ
                    Width = 800, // Chiều rộng cửa sổ
                    Height = 400, // Chiều cao cửa sổ
                    Content = new DataGrid // Nội dung cửa sổ là một DataGrid
                    {
                        AutoGenerateColumns = false, // Tắt chế độ tự động tạo cột
                        ItemsSource = db.SanPhams // Nguồn dữ liệu lấy từ bảng SanPham
                            .Include(sp => sp.MaLoaiNavigation) // Bao gồm thông tin loại sản phẩm
                            .Select(sp => new // Tạo kiểu ẩn danh để hiển thị
                            {
                                sp.MaSp, // Mã sản phẩm
                                sp.TenSp, // Tên sản phẩm
                                TenLoai = sp.MaLoaiNavigation.TenLoai, // Tên loại sản phẩm
                                sp.SoLuong, // Số lượng
                                TongTien = sp.DonGia * sp.SoLuong // Tổng tiền bán
                            }).ToList(),
                        Columns = // Định nghĩa các cột của DataGrid
                        {
                            new DataGridTextColumn { Header = "Mã SP", Binding = new Binding("MaSp") },
                            new DataGridTextColumn { Header = "Tên SP", Binding = new Binding("TenSp") },
                            new DataGridTextColumn { Header = "Tên Loại", Binding = new Binding("TenLoai") },
                            new DataGridTextColumn { Header = "Số Lượng", Binding = new Binding("SoLuong") },
                            new DataGridTextColumn { Header = "Tổng Tiền", Binding = new Binding("TongTien") { StringFormat = "N0" } } // Định dạng số với dấu phân cách hàng nghìn
                        }
                    }
                };
                salesWindow.Show(); // Hiển thị cửa sổ thông tin bán hàng
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu không hiển thị được thông tin bán hàng
                MessageBox.Show($"Lỗi khi hiển thị thông tin bán hàng: {ex.Message}", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Hàm xử lý sự kiện khi chọn một dòng trong DataGrid
        private void DgSanPham_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                // Kiểm tra xem có dòng nào được chọn trong DataGrid không
                if (dgSanPham.SelectedItem != null)
                {
                    // Lấy dữ liệu của dòng được chọn (dùng dynamic vì ItemsSource là kiểu ẩn danh)
                    dynamic selected = dgSanPham.SelectedItem;
                    txtMaSP.Text = selected.MaSp; // Hiển thị mã sản phẩm lên TextBox
                    txtTenSP.Text = selected.TenSp; // Hiển thị tên sản phẩm
                    txtDonGia.Text = selected.DonGia.ToString(); // Hiển thị đơn giá
                    txtSoLuong.Text = selected.SoLuong.ToString(); // Hiển thị số lượng
                    cbLoaiSP.SelectedValue = selected.MaLoaiNavigation.MaLoai; // Chọn loại sản phẩm tương ứng trong ComboBox
                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu không hiển thị được thông tin dòng được chọn
                MessageBox.Show($"Lỗi khi chọn sản phẩm: {ex.Message}", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Hàm xóa trắng các trường nhập liệu
        private void ClearInputs()
        {
            try
            {
                // Đặt lại giá trị của các TextBox về chuỗi rỗng
                txtMaSP.Text = txtTenSP.Text = txtDonGia.Text = txtSoLuong.Text = "";
                cbLoaiSP.SelectedIndex = -1; // Bỏ chọn mục trong ComboBox
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu không xóa được các trường nhập liệu
                MessageBox.Show($"Lỗi khi xóa trường nhập liệu: {ex.Message}", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}